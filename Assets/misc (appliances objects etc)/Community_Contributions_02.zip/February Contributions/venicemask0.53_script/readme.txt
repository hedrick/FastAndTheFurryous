This is an interactive, image masking script that revolves around the "magic wand" tool often found in other applications.

Written by: Gert De Roost
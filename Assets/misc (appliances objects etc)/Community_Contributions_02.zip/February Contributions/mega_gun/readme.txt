This is a model of a large, sci-fi gun.

logo that you can change yourself.  It is licensed under a Creative Commons
attributuin 3.0 Unported, where you can read more about at: 
http://creativecommons.org/licenses/by/3.0/

Attribute this work as: "Mehmet PINARCI"
This is a quick tip video on how to align objects in Blender 2.5, without the missing "Copy Attribute" feature from Blender 2.49.

By: Michal Mielczynski
All of these resources are licensed under a Creative Commons
attribution 3.0 Unported. You may read more about it here: 
http://creativecommons.org/licenses/by/3.0/

You are free to use these resources for anything you wish so long as you attribute the work back to the original author(s) below:

Bic Pen
by: Carlos Henrique Passos Jorge

Food Blender
by: Potado Tomado
http://www.youtube.com/user/PotadoTomado?feature=mhw4

Lightsaber
by: James Finnerty

Quartz Clusters
by: Matty Krosschell

Ferrari
by: Stephen Koroknay

Demon head
by: David Street
http://www.brokencolours.co.uk